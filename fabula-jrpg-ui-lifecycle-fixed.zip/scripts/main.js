import {
  createCharacterCard,
  updateCharacterCard,
  updateActiveCombatant,
} from "./ui/character-card.js";

import { setupCommandMenu, updateCommandActor } from "./ui/command-menu.js";

// =====================================================
// UI LIFECYCLE
// =====================================================

function removeFabulaUI() {
  const ui = document.querySelector("#fabula-jrpg-ui");

  if (!ui) {
    return;
  }

  // Remove the keyboard listener registered specifically for this UI.
  if (ui._fabulaKeydownHandler) {
    document.removeEventListener("keydown", ui._fabulaKeydownHandler);
    delete ui._fabulaKeydownHandler;
  }

  ui.remove();
}

export function createFabulaUI() {
  // Never create duplicate HUDs.
  if (document.querySelector("#fabula-jrpg-ui")) {
    return;
  }

  if (!game.combat?.active) {
    return;
  }

  const actors = game.combat.combatants.contents
    .map((combatant) => combatant.actor)
    .filter((actor) => actor?.type === "character");

  const currentActorName = game.combat?.combatant?.actor?.name ?? "";

  const ui = document.createElement("div");

  ui.id = "fabula-jrpg-ui";
  ui.tabIndex = 0;

  ui.innerHTML = `
    <!-- COMMAND MENU -->

    <div class="fui-command" data-actor-name="${currentActorName}">

      <button class="fui-command-button fui-active">
        <span>Attack</span>
      </button>

      <button class="fui-command-button">
        <span>Skill</span>
      </button>

      <button class="fui-command-button">
        <span>Study</span>
      </button>

      <button class="fui-command-button">
        <span>Guard</span>
      </button>

      <button class="fui-command-button">
        <span>Item</span>
      </button>

      <button class="fui-command-button">
        <span>Equipment</span>
      </button>

      <button class="fui-command-button">
        <span>Hinder</span>
      </button>

      <button class="fui-command-button">
        <span>Objective</span>
      </button>

    </div>

    <!-- PARTY -->

    <div class="fui-party-stats">
      ${actors.map(createCharacterCard).join("")}
    </div>
  `;

  document.body.appendChild(ui);

  ui.focus();

  // =========================
  // KEYBOARD
  // =========================

  const keydownHandler = (event) => {
    if (event.key.toLowerCase() !== "f") {
      return;
    }

    const activeSubmenu = ui.querySelector(".fui-submenu:not([hidden])");

    if (activeSubmenu) {
      return;
    }

    event.preventDefault();

    const commandMenu = ui.querySelector(".fui-command");

    if (!commandMenu) {
      return;
    }

    commandMenu.tabIndex = 0;
    commandMenu.focus();

    commandMenu.classList.add("fui-ui-focused");
  };

  // Keep the handler attached to the HUD so it can be removed cleanly.
  ui._fabulaKeydownHandler = keydownHandler;
  document.addEventListener("keydown", keydownHandler);

  // =========================
  // COMMAND MENU
  // =========================

  setupCommandMenu(ui);

  // =========================
  // INITIAL STATE
  // =========================

  updateActiveCombatant(game.combat, ui);
  updateCommandActor(game.combat, ui);
}

function refreshFabulaUI(combat) {
  if (!combat?.active) {
    removeFabulaUI();
    return;
  }

  createFabulaUI();

  const ui = document.querySelector("#fabula-jrpg-ui");

  if (!ui) {
    return;
  }

  updateActiveCombatant(combat, ui);
  updateCommandActor(combat, ui);
}

// =====================================================
// FOUNDry READY
// =====================================================

Hooks.once("ready", () => {
  console.log("Fabula JRPG UI | Ready");

  // Important for players who connect/reload while a combat is already active.
  refreshFabulaUI(game.combat);
});

// =====================================================
// COMBAT START
// =====================================================

Hooks.on("combatStart", (combat) => {
  console.log("Fabula JRPG UI | Combat started");

  refreshFabulaUI(combat);
});

// =====================================================
// COMBAT UPDATES
// =====================================================

// This hook is registered globally, not inside createFabulaUI().
// That allows every connected client to create the HUD when the Combat
// document changes, even if that client did not start the combat.
Hooks.on("updateCombat", (combat) => {
  refreshFabulaUI(combat);
});

// =====================================================
// ACTOR UPDATES
// =====================================================

// Also registered globally so resource changes update the HUD without
// depending on the HUD having already existed when the hook was registered.
Hooks.on("updateActor", (updatedActor) => {
  const ui = document.querySelector("#fabula-jrpg-ui");

  if (!ui) {
    return;
  }

  updateCharacterCard(updatedActor, ui);
});

// =====================================================
// COMBAT END
// =====================================================

Hooks.on("deleteCombat", () => {
  removeFabulaUI();
});
